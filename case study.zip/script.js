const tbody = document.querySelector("#bill-table tbody");
const totalElement = document.getElementById("total");
let bills = [];

function renderBills() {
  tbody.innerHTML = "";
  let totalPayable = 0;

  bills.forEach((bill, index) => {
    const row = document.createElement("tr");

    const consumerCell = document.createElement("td");
    consumerCell.textContent = bill.consumerNumber;

    const selectCell = document.createElement("td");
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = bill.selected;
    checkbox.addEventListener("change", () => {
      bill.selected = checkbox.checked;
      updateTotal();
    });
    selectCell.appendChild(checkbox);

    const dueCell = document.createElement("td");
    dueCell.textContent = bill.dueAmount.toFixed(2);

    const payableCell = document.createElement("td");
    payableCell.textContent = bill.selected ? bill.payable.toFixed(2) : "0.00";

    row.appendChild(consumerCell);
    row.appendChild(selectCell);
    row.appendChild(dueCell);
    row.appendChild(payableCell);
    tbody.appendChild(row);

    if (bill.selected) {
      totalPayable += bill.payable;
    }
  });

  totalElement.textContent = "₹ " + totalPayable.toFixed(2);
}

function updateTotal() {
  let totalPayable = bills.reduce((sum, bill) => bill.selected ? sum + bill.payable : sum, 0);
  totalElement.textContent = "₹ " + totalPayable.toFixed(2);
  renderBills(); // Refresh rows to update Payable column
}

document.querySelector(".pay-btn").addEventListener("click", () => {
  alert("Payment process initiated!");
});

// Fetch bills from bills.json
fetch('bills.json')
  .then(response => response.json())
  .then(data => {
    bills = data;
    renderBills();
  })
  .catch(error => console.error("Failed to load bills.json:", error));
